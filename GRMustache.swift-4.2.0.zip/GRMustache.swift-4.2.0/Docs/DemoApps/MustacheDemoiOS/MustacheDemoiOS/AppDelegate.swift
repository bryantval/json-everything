//
//  AppDelegate.swift
//  MustacheDemoiOS
//
//  Created by Gwendal Roué on 10/03/2015.
//  Copyright (c) 2015 Gwendal Roué. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
}

